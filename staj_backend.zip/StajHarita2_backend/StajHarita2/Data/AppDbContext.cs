﻿using Microsoft.EntityFrameworkCore;
using StajHarita2.Models;

namespace StajHarita2.Data
{
    public class AppDbContext : DbContext
    {
        // This is the constructor. It must be written this way.
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        // Each "model" being CRUD'ed to database needs to have property like this.
        // "Migrations" looks at this to create tables
        // In code, "MapPoints" is seen as an object that contains the "MapPoints" table in the database
        public DbSet<MapPoint> MapPoints { get; set; }
    }
}
