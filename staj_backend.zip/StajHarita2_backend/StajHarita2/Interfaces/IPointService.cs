﻿using StajHarita2.Models;

namespace StajHarita2.Interfaces
{
    public interface IPointService
    {
        List<MapPoint> GetAllPoints();
        ResponseMapPoint AddPoint(MapPoint p);
        ResponseMapPoint GetPointById(int id);
        ResponseMapPoint UpdatePoint(int id, MapPoint updatedPoint);
        ResponseMapPoint DeletePoint(int id);
    }
}
