﻿namespace StajHarita2.DTOs
{
    public class DTO_MapPoint
    {
        public int Id { get; set; }
        public string? PointWKT { get; set; }
        public string? Name { get; set; }
    }
}
