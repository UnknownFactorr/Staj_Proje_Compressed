﻿using System.ComponentModel.DataAnnotations;

namespace StajHarita2.DTOs
{
    public class DTO_UserInput_MapPoint
    {
        //public int? Id { get; set; }

        [Required]
        public string? PointWKT { get; set; }
        
        [Required]
        public string? Name { get; set; }
    }

}
