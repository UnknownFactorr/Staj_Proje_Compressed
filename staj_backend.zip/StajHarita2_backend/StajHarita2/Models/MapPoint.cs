﻿using NetTopologySuite.Geometries;

namespace StajHarita2.Models
{
    public class MapPoint
    {
        public int Id { get; set; }
        public Point? PointGeometry { get; set; }
        public string? Name { get; set; }
    }
}
