﻿using StajHarita2.DTOs;

namespace StajHarita2.Models
{
    public class ResponseMapPointList
    {
        public string? Message { get; set; }
        public List<DTO_MapPoint>? Data { get; set; }
        public bool? Success { get; set; }
    }
}
