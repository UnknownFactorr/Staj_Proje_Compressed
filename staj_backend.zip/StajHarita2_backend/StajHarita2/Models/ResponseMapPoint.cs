﻿using StajHarita2.DTOs;

namespace StajHarita2.Models
{
    public class ResponseMapPoint
    {
        public string? Message { get; set; }
        public DTO_MapPoint? Data { get; set; }
        public bool? Success { get; set; }
    }
}
