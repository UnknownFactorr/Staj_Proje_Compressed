﻿using StajHarita2.Interfaces;
using StajHarita2.Models;

namespace StajHarita2.Services
{
    public class PointService
    {
        
    }
}
