﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using NetTopologySuite.Geometries;
using StajHarita2.Data;
using StajHarita2.DTOs;
using StajHarita2.Models;
using NetTopologySuite.IO;
using System.Drawing;
// this line is usefull
using Point = NetTopologySuite.Geometries.Point;

namespace StajHarita2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PointController : ControllerBase
    {
        // Create a "DbContext" to access the database
        private readonly AppDbContext _context;

        // Use the constuctor to...
        public PointController(AppDbContext context)
        {
            _context = context;
        }


        [HttpGet]
        public async Task<ActionResult<ResponseMapPointList>> GetAllPoints()
        {
            // create a list and put all "MapPoint"s in the database inside it
            //// List<MapPoint>
            var pointEntities = await _context.MapPoints.ToListAsync();

            // 2) Convert each one into response‐DTO
            //
            // Create a "WKTWriter". this is just to translate the "PointGeomtery" to "PointWkt"
            //// WKTWriter
            var writer = new NetTopologySuite.IO.WKTWriter();
            // Create a list of "DTO_MapPoint", use ".Select()" function to add each "MapPoint" in it as a "DTO"
            var listDto = pointEntities.Select(e => new DTO_MapPoint
                {
                    Id = e.Id,
                    Name = e.Name!,
                    // use "WKTWriter" to turn "PointGeometry" into "PointWKT"
                    PointWKT = writer.Write(e.PointGeometry!)
                })
                .ToList();

            // 3) Wrap in the new list‐response and return
            //
            // return "listDTO" inside a "Response".
            // "response type" that is used here is a list and only use in this "GetAll" function
            return Ok(new ResponseMapPointList
            {
                Success = true,
                Message = "All points retrieved",
                Data = listDto
            });
        }


        [HttpGet("{id}")]
        public async Task<ActionResult<ResponseMapPoint>> GetPointById(int id)
        {
            // create a "var" to store the "point" with the matching id. Stores "null" if no Id match is found.
            var pointEntity = await _context.MapPoints.FindAsync(id);
            // if no id match is found, create and fill a failed "response" object before returning the "response" object
            if (pointEntity == null)
                return NotFound(new ResponseMapPoint
                {
                    Success = false,
                    Message = "Point not found",
                    Data = null
                });

            // Map to DTO
            //
            // create a "WKTWriter"
            // create a "DTO_response" and fill it with the data of the received "point"...
            // ...when it comes to "WKT" use "WKTWriter" to the "geometry" data from database
            var writer = new WKTWriter();
            var outDto = new DTO_MapPoint
            {
                Id = pointEntity.Id,
                Name = pointEntity.Name!,
                PointWKT = writer.Write(pointEntity.PointGeometry!)
            };

            // Return DTO inside a "Response"
            return Ok(new ResponseMapPoint
            {
                Success = true,
                Message = "Success",
                Data = outDto
            });
        }


        [HttpPost]
        public async Task<ActionResult<ResponseMapPoint>> AddPoint(DTO_UserInput_MapPoint toBeSavedDTO_MapPoint)
        {
            // create a "WKTReader"
            // create a "Point" from netTopologySuite
            // inside try, create a geometry to store WKT given by user
            // check if thing read by WKTReader is stored as NetTopogySuit Point. If its netTop Line, Polygon etc. throw new exception.
            // if its a point
            var reader = new WKTReader();
            Point point;
            try
            {
                var geom = reader.Read(toBeSavedDTO_MapPoint.PointWKT!);
                if (geom is not Point p)
                    throw new Exception("Not a Point");
                point = p;
            }
            catch
            {
                return BadRequest(new ResponseMapPoint
                {
                    Success = false,
                    Data = null,
                    Message = "Invalid WKT format"
                });
            }

            // create a "MapPoint", NOT A "NetTopologySuite" POINT !!!
            // Put name given as parameter and point location data tarnsformed to a netTop point into this "MapPoint"
            var mapPointEntity = new MapPoint
            {
                Name = toBeSavedDTO_MapPoint.Name,
                PointGeometry = point
            };

            // use dbContext to save "MapPoint" to database
            // use dbContext and ".saveChangesAsync" to actually save the "MapPoint" to database
            _context.MapPoints.Add(mapPointEntity);
            await _context.SaveChangesAsync();

            // create a WKTWriter
            // create a DTO_MapPoint, fill it with data. WKT is stored as a "string" 
            // 
            var writer = new WKTWriter();
            var outDto = new DTO_MapPoint
            {
                Id = mapPointEntity.Id,
                Name = mapPointEntity.Name!,
                PointWKT = writer.Write(mapPointEntity.PointGeometry!)
            };

            // create a "Response", NOT A DTO_RESPONSE
            // Return a "Response" to user. This response stores "DTO_MapPoint" as its data field
            return Ok(new ResponseMapPoint
            {
                Success = true,
                Data = outDto,
                Message = "Point created"
            });
        }


        [HttpPut("{id}")]
        public async Task<ActionResult<ResponseMapPoint>> UpdatePoint(int id, DTO_UserInput_MapPoint dto)
        {
            // 1) Load existing
            //
            // Create a "MapPoint" to store the "MapPoint" from database
            // if there is no "MapPoint" in the database with the given id, it stores null
            var mapPointEntity = await _context.MapPoints.FindAsync(id);
            // if its filled with null, create and return a "failed ResponseMapPoint"
            if (mapPointEntity == null)
                return NotFound(new ResponseMapPoint
                {
                    Success = false,
                    Data = null,
                    Message = "Point not found"
                });

            // 2) Parse new WKT
            //
            // create a "WKTReader"
            var reader = new WKTReader();
            // create NetTopologSuite "Point"
            Point point;
            // create a "Geometry" to store the user input, user reader to transform it
            // if "Geometry" is not "netTopologySuite Point" use a "BadRequest" to send a "Failed ResponseMapPoint"
            try
            {
                var geom = reader.Read(dto.PointWKT!);
                if (geom is not Point p)
                    throw new Exception();
                point = p;
            }
            catch
            {
                return BadRequest(new ResponseMapPoint
                {
                    Success = false,
                    Data = null,
                    Message = "Invalid WKT format"
                });
            }

            // 3) Apply update to databse
            //
            // since if code here is run, it means the given point was valid
            // put user input into "mappointEntity", save changes to database
            mapPointEntity.Name = dto.Name;
            mapPointEntity.PointGeometry = point;
            await _context.SaveChangesAsync();

            // 4) Return a "Resposne" object to user
            //
            // create a "WKTWriter"
            var writer = new WKTWriter();
            // create a "DTO_MapPoint", fill it with the data of "mapPointEntity" which holds updated points data
            var outDto = new DTO_MapPoint
            {
                Id = mapPointEntity.Id,
                Name = mapPointEntity.Name!,
                PointWKT = writer.Write(mapPointEntity.PointGeometry!)
            };
            // create and return a "Response" to user
            // int "Response"s data field, put "DTO_MapPoint" filled with "mapPointEntity"s data
            return Ok(new ResponseMapPoint
            {
                Success = true,
                Data = outDto,
                Message = "Point updated"
            });
        }


        [HttpDelete("{id}")]
        public async Task<ActionResult<ResponseMapPoint>> DeletePoint(int id)
        {
            // create a "MapPoint" and fill it with the data of "MapPoint" with matching ID from database
            var mapPointEntity = await _context.MapPoints.FindAsync(id);
            // if there is no id match in database return a "Failed Response"
            if (mapPointEntity == null)
                return NotFound(new ResponseMapPoint
                {
                    Success = false,
                    Data = null,
                    Message = "Point not found"
                });

            // if "MapPoint" with the given id is found remove it, update the database
            _context.MapPoints.Remove(mapPointEntity);
            await _context.SaveChangesAsync();

            // return a "Success Response"
            // since this is a deletion process, I did not bother with filling "Data" field of "Response" 
            return Ok(new ResponseMapPoint
            {
                Success = true,
                Data = null,
                Message = "Point deleted"
            });
        }
    }
}