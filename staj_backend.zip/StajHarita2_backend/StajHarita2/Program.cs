using Microsoft.EntityFrameworkCore;
using StajHarita2.Data;
using StajHarita2.Interfaces;
using StajHarita2.Services;

var builder = WebApplication.CreateBuilder(args);



// Register DbContext with PostgreSQL
builder.Services.AddDbContext<AppDbContext>(options =>
options.UseNpgsql(
builder.Configuration.GetConnectionString("DefaultConnection"),
npgsql => npgsql.UseNetTopologySuite()
     )
 );

// enable NetTopologySuite
//builder.Services.AddDbContext<AppDbContext>(opts =>
//    opts.UseNpgsql(
//      builder.Configuration.GetConnectionString("DefaultConnection"),
//      x => x.UseNetTopologySuite()
//    )
//);





// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();







var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
