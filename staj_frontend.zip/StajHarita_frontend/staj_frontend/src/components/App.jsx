import React from "react";
import Header from "./Header";
import MapView from "./Map/MapView";

function App() {
  return (
    <div>
      <Header />
      <MapView />
    </div>
  );
}

export default App;
