import React from "react";

function Header() {
  return (
    <header>
      <button>Noktaları Listede Görüntüle</button>
      <button>Noktaları Haritada Görüntüle </button>
      <button>Nokta Ekle</button>
      <button>Nokta Düzenle</button>
      <button>Nokta Sil</button>
    </header>
  );
}

export default Header;