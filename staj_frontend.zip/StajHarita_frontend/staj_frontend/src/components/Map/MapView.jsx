import React, { useEffect, useRef } from 'react';
import Map from 'ol/Map';
import View from 'ol/View';
import TileLayer from 'ol/layer/Tile';
import VectorLayer from 'ol/layer/Vector';
import VectorSource from 'ol/source/Vector';
import OSM from 'ol/source/OSM';
import GeoJSON from 'ol/format/GeoJSON';
import { fromLonLat } from 'ol/proj';
import { Style, Stroke, Fill } from 'ol/style';
import 'ol/ol.css';

export default function MapView() {
  // Create a ref for the map container DIV
  const mapRef = useRef();

  useEffect(() => {
    // 1) Base OSM layer
    const osmLayer = new TileLayer({
      source: new OSM()
    });

    // 2) Provinces vector layer loading your GeoJSON file
    const provincesLayer = new VectorLayer({
      source: new VectorSource({
        // process.env.PUBLIC_URL resolves to '/' in CRA,
        // so this points to '/turkey_provinces.geojson'
        url: process.env.PUBLIC_URL + '/turkey_provinces.geojson',
        format: new GeoJSON()
      }),
      // Style: just draw boundaries (stroke), no fill
      style: new Style({
  stroke: new Stroke({ color: '#333', width: 1 }),
  fill:   new Fill({ color: 'rgba(0, 0, 0, 0)' })
})

    });

    // 3) Create the map
    const map = new Map({
      target: mapRef.current,      // attach to the div via ref
      layers: [osmLayer, provincesLayer],
      view: new View({
        center: fromLonLat([35, 39]), // Lon, Lat of Turkey center
        zoom: 6
      })
    });

    // Clean up on unmount
    return () => map.setTarget(undefined);
  }, []);

  // Render the DIV that OpenLayers will draw into
  return (
    <div 
      ref={mapRef} 
      id="map" 
      style={{ width: '100%', height: '500px' }} 
    />
  );
}
